<?php
/**
 * @file
 * Interaction: Modify.
 */

namespace Drupal\openlayers\Plugin\Interaction\Modify;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Interaction;

/**
 * Class Modify.
 *
 * @OpenlayersPlugin(
 *  id = "Modify"
 * )
 */
class Modify extends Interaction {

}
