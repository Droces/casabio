Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.Component:LazyProcessing',
  init: function(data) {
  }
});
