<?php
/**
 * @file
 * Interface InteractionInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface InteractionInterface.
 */
interface InteractionInterface extends ObjectInterface {

}
