<?php
/**
 * @file
 * Interface SourceInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface SourceInterface.
 */
interface SourceInterface extends ObjectInterface {

}
