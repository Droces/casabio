<?php
/**
 * @file
 * Source: Vector.
 */

namespace Drupal\openlayers\Plugin\Source\Vector;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Source;

/**
 * Class Vector.
 *
 * @OpenlayersPlugin(
 *  id = "Vector"
 * )
 */
class Vector extends Source {

}
