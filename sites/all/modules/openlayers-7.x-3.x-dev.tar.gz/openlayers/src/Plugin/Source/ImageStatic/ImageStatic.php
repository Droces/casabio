<?php
/**
 * @file
 * Source: ImageStatic.
 */

namespace Drupal\openlayers\Plugin\Source\ImageStatic;
use Drupal\openlayers\Component\Annotation\OpenlayersPlugin;
use Drupal\openlayers\Types\Source;

/**
 * Class ImageStatic.
 *
 * @OpenlayersPlugin(
 *  id = "ImageStatic"
 * )
 */
class ImageStatic extends Source {

}
