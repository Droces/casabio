<?php
/**
 * @file
 * Class Projection.
 */

namespace Drupal\openlayers\Types;

/**
 * Class Projection.
 */
abstract class Projection extends Object implements ProjectionInterface {

}
