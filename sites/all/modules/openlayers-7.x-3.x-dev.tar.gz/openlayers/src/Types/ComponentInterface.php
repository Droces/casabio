<?php
/**
 * @file
 * Interface ComponentInterface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface ComponentInterface.
 */
interface ComponentInterface extends ObjectInterface {

}
